# ================== Week 6: Incremental LoRA Resume Script (Full) ==================
# - Loads base model/tokenizer
# - Mounts Week-5 adapter (or attaches fresh LoRA)
# - Resumes from the latest Week-5 HF checkpoint if available
# - Logs to Week-6 folders and saves a new Week-6 adapter
# ================================================================================

import os, sys, glob, csv, math, torch
from typing import Optional, Dict
from huggingface_hub import login
from datasets import load_dataset
from transformers import (
    AutoTokenizer, AutoModelForCausalLM,
    TrainingArguments, Trainer, DataCollatorForLanguageModeling
)
from peft import PeftModel, LoraConfig, get_peft_model, TaskType

# ====== CONFIG ======
HF_TOKEN   = os.environ.get("HF_TOKEN", "hf_XXXXXXXXXXXXX")
BASE_MODEL = "meta-llama/Meta-Llama-3.1-8B"

# Week-5 artifacts (source)
PREV_RUNS  = r"D:\Hoa_teaching_graduate_classes\2025_fall\W5_materials"
PREV_ADAPT = r"D:\Hoa_teaching_graduate_classes\2025_fall\W5_materials\week5_lora_v01"

# Week-6 outputs (destination)
OUT_RUNS_W6  = r"D:\Hoa_teaching_graduate_classes\2025_fall\W6_materials"
OUT_LOGS_W6  = os.path.join(OUT_RUNS_W6, "logs")
OUT_ADAPT_W6 = os.path.join(OUT_RUNS_W6, "week6_lora_v01")

# Data (merge with Week-5 now as replay sets; or use whole new data JSONL)
DATA_PATH_W6 = r"D:\Hoa_teaching_graduate_classes\2025_fall\W6_materials\all.jsonl"

# Tokenization / training knobs
MAX_LEN   = 2048
BATCH     = 1
GRAD_ACC  = 16
LR        = 1e-4       # smaller LR for stable incremental
EPOCHS    = 1
LORA_R    = 16
LORA_ALPHA= 32
LORA_DROPOUT = 0.05
INCLUDE_MLP  = True
# =====================

def ensure_token():
    if not HF_TOKEN.startswith("hf_"):
        print("[!] HF_TOKEN is not set. Set env var HF_TOKEN or edit this file.", file=sys.stderr)
        raise SystemExit(1)
    login(HF_TOKEN)

def load_base_model_and_tokenizer():
    print("[+] Loading tokenizer & base model:", BASE_MODEL)
    tok = AutoTokenizer.from_pretrained(BASE_MODEL, use_fast=True, token=HF_TOKEN)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    try:
        mdl = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL,
            token=HF_TOKEN,
            device_map="auto",
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16
        )
        print("[+] Loaded base model with QLoRA (4-bit).")
    except Exception as e:
        print("[!] 4-bit load failed; fallback to fp16. Error:", e)
        mdl = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL,
            token=HF_TOKEN,
            device_map="auto",
            torch_dtype=torch.float16
        )
        print("[+] Loaded base model in fp16 fallback.")
    if hasattr(mdl, "config"):
        mdl.config.use_cache = False
    return mdl, tok

def attach_new_lora(model):
    print("[+] Attaching fresh LoRA adapters ...")
    targets = ["q_proj","k_proj","v_proj","o_proj"]
    if INCLUDE_MLP:
        targets += ["gate_proj","up_proj","down_proj"]
    cfg = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=LORA_R, lora_alpha=LORA_ALPHA, lora_dropout=LORA_DROPOUT,
        target_modules=targets
    )
    peft_model = get_peft_model(model, cfg)
    trainable = sum(p.numel() for p in peft_model.parameters() if p.requires_grad)
    total     = sum(p.numel() for p in peft_model.parameters())
    print(f"[+] LoRA attached. Trainable params: {trainable:,} / {total:,}")
    return peft_model

def load_prev_adapter_or_fresh(model):
    if os.path.isdir(PREV_ADAPT):
        print("[+] Loading Week-5 LoRA adapter:", PREV_ADAPT)
        return PeftModel.from_pretrained(model, PREV_ADAPT)
    print("[!] Previous adapter not found -> attaching fresh LoRA.")
    return attach_new_lora(model)

def find_latest_checkpoint(run_dir: str) -> Optional[str]:
    if not os.path.isdir(run_dir):
        return None
    checkpoints = sorted(
        [p for p in glob.glob(os.path.join(run_dir, "checkpoint-*")) if os.path.isdir(p)],
        key=lambda p: int(p.rsplit("-", 1)[-1]) if p.rsplit("-", 1)[-1].isdigit() else -1
    )
    return checkpoints[-1] if checkpoints else None

def format_row(r: Dict) -> Dict:
    for key in ["system", "instruction", "context", "answer"]:
        if key not in r or not str(r[key]).strip():
            meta = r.get("meta", {})
            raise ValueError(f"Missing/empty '{key}' in record (meta={meta})")
    prompt = f"{r['system'].strip()}\n\nInstruction: {r['instruction'].strip()}\nContext: {r['context'].strip()}\nAnswer:"
    return {"prompt": prompt, "label": r["answer"].strip()}

def load_and_prepare_dataset(tokenizer, data_path: str):
    if not os.path.isfile(data_path):
        raise FileNotFoundError(f"DATA_PATH not found: {data_path}")
    print("[+] Loading dataset:", data_path)
    raw = load_dataset("json", data_files=data_path)["train"]
    ds = raw.map(format_row)

    def tokenize(batch):
        enc_p = tokenizer(batch["prompt"], truncation=True, max_length=MAX_LEN)
        enc_a = tokenizer(batch["label"],  truncation=True, max_length=MAX_LEN)
        input_ids = enc_p["input_ids"] + enc_a["input_ids"]
        attention = [1] * len(input_ids)
        labels    = [-100] * len(enc_p["input_ids"]) + enc_a["input_ids"]
        return {"input_ids": input_ids, "attention_mask": attention, "labels": labels}

    return ds.map(tokenize, remove_columns=ds.column_names)

def train_resume(model, tokenizer, tok_ds):
    os.makedirs(OUT_RUNS_W6, exist_ok=True)
    os.makedirs(OUT_LOGS_W6, exist_ok=True)

    args = TrainingArguments(
        output_dir=OUT_RUNS_W6,
        logging_dir=OUT_LOGS_W6,
        report_to="tensorboard",
        logging_steps=20,
        num_train_epochs=EPOCHS,
        per_device_train_batch_size=BATCH,
        gradient_accumulation_steps=GRAD_ACC,
        learning_rate=LR,
        warmup_ratio=0.0,                 # no warmup on resume
        lr_scheduler_type="cosine",
        save_steps=500,
        save_total_limit=2,
        bf16=True
    )
    collator = DataCollatorForLanguageModeling(tokenizer, mlm=False)
    trainer = Trainer(model=model, args=args, data_collator=collator, train_dataset=tok_ds)

    ckpt = find_latest_checkpoint(PREV_RUNS)
    if ckpt:
        print("[+] Resuming from Week-5 checkpoint:", ckpt)
        result = trainer.train(resume_from_checkpoint=ckpt)
    else:
        print("[!] No Week-5 HF checkpoint found; continuing from loaded adapter weights.")
        result = trainer.train()

    metrics = result.metrics
    trainer.log_metrics("train", metrics)
    trainer.save_metrics("train", metrics)
    trainer.save_state()

    # CSV log
    csv_path = os.path.join(OUT_RUNS_W6, "loss_log_w6.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["step","epoch","loss","learning_rate"])
        for rec in trainer.state.log_history:
            if "loss" in rec:
                w.writerow([rec.get("step"), rec.get("epoch"), rec.get("loss"), rec.get("learning_rate")])
    print("[+] Wrote Week-6 loss CSV:", csv_path)

    tl = metrics.get("train_loss")
    if tl is not None and tl < 20:
        print(f"[+] Final train loss: {tl:.4f} | Perplexity: {math.exp(tl):.2f}")
    return trainer

def save_adapter(trainer, tokenizer):
    os.makedirs(OUT_ADAPT_W6, exist_ok=True)
    trainer.model.save_pretrained(OUT_ADAPT_W6)
    tokenizer.save_pretrained(OUT_ADAPT_W6)
    print("[+] Saved Week-6 LoRA adapter + tokenizer to:", OUT_ADAPT_W6)

def smoke_test(model, tokenizer):
    print("[+] Running smoke test generation ...")
    prompt = (
        "You are a geology and hyperspectral remote sensing assistant.\n\n"
        "Instruction: Summarize how dolomitization affected economic value in the study.\n"
        "Context: Results show igneous intrusion reduced economic value by ~80% compared to pure limestone, "
        "and hydrothermal alteration caused extensive dolomitization, transforming limestone into dolostone.\n"
        "Answer:"
    )
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        out_ids = model.generate(**inputs, max_new_tokens=200, do_sample=False,
                                 eos_token_id=tokenizer.eos_token_id)
    print("\n[SMOKE TEST OUTPUT]\n", tokenizer.decode(out_ids[0], skip_special_tokens=True), "\n")

def main():
    # Optional: print versions for reproducibility
    try:
        import transformers, datasets, peft, accelerate
        print("Versions -> transformers:", transformers.__version__,
              "| datasets:", datasets.__version__,
              "| peft:", peft.__version__,
              "| accelerate:", accelerate.__version__)
    except Exception:
        pass

    ensure_token()
    model, tokenizer = load_base_model_and_tokenizer()
    model = load_prev_adapter_or_fresh(model)
    tok_ds = load_and_prepare_dataset(tokenizer, DATA_PATH_W6)
    trainer = train_resume(model, tokenizer, tok_ds)
    save_adapter(trainer, tokenizer)
    smoke_test(trainer.model, tokenizer)

if __name__ == "__main__":
    main()
