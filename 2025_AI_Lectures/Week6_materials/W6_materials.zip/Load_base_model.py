# --- 2.1: Load base model + mount last Week-5 LoRA adapter ---

import os, sys, torch
from typing import Optional, Dict
from huggingface_hub import login
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel, LoraConfig, get_peft_model, TaskType

HF_TOKEN   = os.environ.get("HF_TOKEN", "hf_XXXXXXXXXXXXX")
BASE_MODEL = "meta-llama/Meta-Llama-3.1-8B"

PREV_ADAPT = r"D:\Hoa_teaching_graduate_classes\2025_fall\W5_materials\week5_lora_v01"  # Week-5 adapter

LORA_R         = 16
LORA_ALPHA     = 32
LORA_DROPOUT   = 0.05
INCLUDE_MLP    = True  # attn+MLP targets like Week-5

def ensure_token():
    if not HF_TOKEN.startswith("hf_"):
        print("[!] HF_TOKEN is not set. Set env var HF_TOKEN or edit this file.", file=sys.stderr)
        raise SystemExit(1)
    login(HF_TOKEN)

def load_base_model_and_tokenizer():
    print("[2.1] Loading tokenizer & base model:", BASE_MODEL)
    tok = AutoTokenizer.from_pretrained(BASE_MODEL, use_fast=True, token=HF_TOKEN)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    try:
        mdl = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL,
            token=HF_TOKEN,
            device_map="auto",
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16
        )
        print("[2.1] Loaded base model with QLoRA (4-bit).")
    except Exception as e:
        print("[2.1] 4-bit load failed; fallback to fp16. Error:", e)
        mdl = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL,
            token=HF_TOKEN,
            device_map="auto",
            torch_dtype=torch.float16
        )
        print("[2.1] Loaded base model in fp16 fallback.")
    if hasattr(mdl, "config"):
        mdl.config.use_cache = False
    return mdl, tok

def attach_new_lora(model):
    print("[2.1] Attaching fresh LoRA adapters ...")
    targets = ["q_proj","k_proj","v_proj","o_proj"]
    if INCLUDE_MLP:
        targets += ["gate_proj","up_proj","down_proj"]
    cfg = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=LORA_R, lora_alpha=LORA_ALPHA, lora_dropout=LORA_DROPOUT,
        target_modules=targets
    )
    peft_model = get_peft_model(model, cfg)
    trainable = sum(p.numel() for p in peft_model.parameters() if p.requires_grad)
    total     = sum(p.numel() for p in peft_model.parameters())
    print(f"[2.1] LoRA attached. Trainable params: {trainable:,} / {total:,}")
    return peft_model

def load_prev_adapter_or_fresh(model):
    if os.path.isdir(PREV_ADAPT):
        print("[2.1] Loading Week-5 LoRA adapter:", PREV_ADAPT)
        return PeftModel.from_pretrained(model, PREV_ADAPT)
    print("[2.1] Previous adapter not found -> attaching fresh LoRA.")
    return attach_new_lora(model)

# Demo (students can comment these in the full script's main())
# ensure_token()
# model, tokenizer = load_base_model_and_tokenizer()
# model = load_prev_adapter_or_fresh(model)
