# Step 1: Extract text from a DOCX file
# File path: D:\Hoa_teaching_graduate_classes\example.docx

import docx

# Input and output paths
docx_path = r"D:\Hoa_teaching_graduate_classes\example.docx"
output_path = r"D:\Hoa_teaching_graduate_classes\example_extracted.txt"

def extract_text_from_docx(docx_file, output_file):
    doc = docx.Document(docx_file)

    all_text = ""
    for para in doc.paragraphs:
        text = para.text.strip()
        if text:  # skip empty lines
            all_text += text + "\n"

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(all_text)

    print(f"✅ Extraction complete! Text saved to: {output_file}")

# Run the function
extract_text_from_docx(docx_path, output_path)
