import os
import json

def chunk_text(file_path, chunk_size=500, overlap=50, output_dir="chunks_output"):
    """
    Split a cleaned .txt file into chunks with optional overlap.

    Args:
        file_path (str): path to input .txt file
        chunk_size (int): number of words per chunk
        overlap (int): number of words to overlap between chunks
        output_dir (str): directory to save chunked files

    Returns:
        List of chunk dictionaries with metadata
    """
    # Read text
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()

    # Split into words
    words = text.split()

    # Create output directory
    os.makedirs(output_dir, exist_ok=True)

    chunks = []
    step = chunk_size - overlap  # move forward less than chunk size to create overlap
    for i in range(0, len(words), step):
        chunk_words = words[i:i + chunk_size]
        if not chunk_words:
            continue
        chunk_text = " ".join(chunk_words)

        # Metadata
        chunk_id = len(chunks) + 1
        chunk_data = {
            "chunk_id": chunk_id,
            "source_file": os.path.basename(file_path),
            "text": chunk_text
        }
        chunks.append(chunk_data)

        # Save each chunk as a text file
        chunk_file = os.path.join(output_dir, f"chunk_{chunk_id}.txt")
        with open(chunk_file, "w", encoding="utf-8") as cf:
            cf.write(chunk_text)

    # Also save everything as one JSON file
    json_file = os.path.join(output_dir, "chunks.json")
    with open(json_file, "w", encoding="utf-8") as jf:
        json.dump(chunks, jf, indent=2, ensure_ascii=False)

    print(f"✅ Done! {len(chunks)} chunks created with overlap={overlap}, saved in '{output_dir}'")
    return chunks


# === Example usage ===
if __name__ == "__main__":
    file_path = r"D:\Hoa_teaching_graduate_classes\2025_fall\W4_materials\example_cleaned.txt"
    chunk_text(file_path, chunk_size=500, overlap=50)
