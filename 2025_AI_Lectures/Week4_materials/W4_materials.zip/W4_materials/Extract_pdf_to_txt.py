# Step 1: Extract text from a PDF
# File path: D:\Hoa_teaching_graduate_classes\example.pdf

import PyPDF2

# Path to your PDF file
pdf_path = r"D:\Hoa_teaching_graduate_classes\1-s2.0-S1569843225003668-main.pdf"

# Output file to save extracted text
output_path = r"D:\Hoa_teaching_graduate_classes\example_extracted.txt"

def extract_text_from_pdf(pdf_file, output_file):
    # Open the PDF in read-binary mode
    with open(pdf_file, "rb") as file:
        reader = PyPDF2.PdfReader(file)

        print(f"Total pages: {len(reader.pages)}")

        all_text = ""
        for page_num in range(len(reader.pages)):
            page = reader.pages[page_num]
            text = page.extract_text() or ""  # extract_text() may return None
            all_text += f"\n--- Page {page_num+1} ---\n"
            all_text += text.strip() + "\n"

    # Save extracted text to a .txt file
    with open(output_file, "w", encoding="utf-8") as out_file:
        out_file.write(all_text)

    print(f"✅ Extraction complete! Text saved to: {output_file}")

# Run the function
extract_text_from_pdf(pdf_path, output_path)
