import json
import re
import hashlib
from pathlib import Path

# --- very small helpers ------------------------------------------------------
SECTION_RULES = [
    (re.compile(r'\babstract\b', re.I), "Abstract"),
    (re.compile(r'\bintroduction\b', re.I), "Introduction"),
    (re.compile(r'\bmaterials?\s+and\s+methods|\bmethods?\b|\bmethodology\b', re.I), "Materials and Methods"),
    (re.compile(r'\bresults?\b', re.I), "Results"),
    (re.compile(r'\bdiscussion(s)?\b|\bresults\s+and\s+discussion\b', re.I), "Discussion"),
    (re.compile(r'\bconclusion(s)?\b', re.I), "Conclusions"),
]

KEYWORDS = {
    "hyperspectral": ["hyperspectral", "SWIR", "VNIR", "reflectance", "spectra"],
    "geology": ["litholog", "petrograph", "igneous", "carbonate", "quarry"],
    "limestone": ["limestone", "calcite", "caco3"],
    "dolostone": ["dolostone", "dolomite", "mg-oh"],
    "igneous intrusion": ["dyke", "intrusion", "granodiorite", "diorite", "granite"],
    "machine learning": ["random forest", " rf ", "classifier"],
    "deep learning": ["3d-cnn", "cnn", "convolution"],
    "geochemistry": ["pxrf", "xrf", "sio2", "cao", "mgo"],
}

def infer_section(text: str) -> str:
    head = text[:500]
    for pat, name in SECTION_RULES:
        if pat.search(head):
            return name
    # handle numbered headings like "2.3." etc.
    if re.search(r'^\s*\d+(\.\d+)*\s+[A-Za-z]', text, re.M):
        return "Numbered Section"
    return "Unknown"

def auto_tags(text: str, base=None):
    base = base or []
    t = " " + text.lower() + " "  # pad for ' rf ' detection
    found = []
    for tag, needles in KEYWORDS.items():
        if any(n in t for n in needles):
            found.append(tag)
    # unique, preserve order (base first)
    out, seen = [], set()
    for tag in (base + found):
        if tag not in seen:
            out.append(tag)
            seen.add(tag)
    return out

def stable_id(source: str, idx: int, text: str) -> str:
    seed = f"{source}::{idx}::{text[:160]}"
    return hashlib.md5(seed.encode("utf-8")).hexdigest()

# --- main --------------------------------------------------------------------
def add_minimal_metadata(
    input_json: str,
    output_json: str,
    title: str,
    year: int,
    doi: str = "",
    authors=None,
    base_tags=None,
):
    authors = authors or []
    base_tags = base_tags or ["hyperspectral", "geology"]

    with open(input_json, "r", encoding="utf-8") as f:
        chunks = json.load(f)
    if not isinstance(chunks, list):
        raise ValueError("Input JSON must be a list of chunk dicts.")
    source_name = Path(input_json).name

    for i, ch in enumerate(chunks):
        text = ch.get("text", "")
        # core bibliographic
        ch.setdefault("title", title)
        ch.setdefault("year", year)
        if doi:
            ch.setdefault("doi", doi)
        if authors:
            ch.setdefault("authors", authors)

        # light metadata
        if not ch.get("section"):
            ch["section"] = infer_section(text)
        ch["tags"] = auto_tags(text, base_tags)
        ch["word_count"] = len(text.split())
        ch["id"] = ch.get("id") or stable_id(source_name, ch.get("chunk_id", i), text)

        # keep a simple provenance hint
        ch.setdefault("source_file", source_name)

    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(chunks, f, indent=2, ensure_ascii=False)
    print(f"✅ Wrote {len(chunks)} chunks with minimal metadata → {output_json}")

# ---- example usage ----------------------------------------------------------
if __name__ == "__main__":
    add_minimal_metadata(
        input_json=r"D:\Hoa_teaching_graduate_classes\2025_fall\W4_materials\chunks_output\chunks.json",
        output_json=r"D:\Hoa_teaching_graduate_classes\2025_fall\W4_materials\chunks_output\chunks_with_metadata.json",
        title=("Detection of mineralogical and lithological transitions in igneous intrusion–limestone boundaries using close-range hyperspectral remote sensing: a resource perspective"),
        year=2025,
        doi="10.1016/j.jag.2025.104719",
        authors=["Huy Hoa Huynh", "Jaehyung Yu", "Lei Wang", "Trung Hieu Pham", "Jin-Young Lee"],
        base_tags=["hyperspectral", "geology", "igneous intrusion"]
    )
