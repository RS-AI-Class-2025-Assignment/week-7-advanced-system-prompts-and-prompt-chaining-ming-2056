# D:\Hoa_teaching_graduate_classes\2025_fall\Week5\scripts\merge_json_to_jsonl.py
import json
import glob
import os

SRC_DIR = r"D:\Hoa_teaching_graduate_classes\2025_fall\W5_materials"
OUT_PATH = r"D:\Hoa_teaching_graduate_classes\2025_fall\W5_materials\all.jsonl"

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)

count_in, count_out = 0, 0

with open(OUT_PATH, "w", encoding="utf-8") as fout:
    for fname in glob.glob(os.path.join(SRC_DIR, "*.json")):
        count_in += 1
        with open(fname, "r", encoding="utf-8") as fin:
            obj = json.load(fin)

            # If it's a list, iterate through items
            if isinstance(obj, list):
                for item in obj:
                    if isinstance(item, dict):
                        if "system" not in item:
                            item["system"] = "You are a geology and hyperspectral remote sensing assistant."
                        fout.write(json.dumps(item, ensure_ascii=False) + "\n")
                        count_out += 1
            # If it's a single dict
            elif isinstance(obj, dict):
                if "system" not in obj:
                    obj["system"] = "You are a geology and hyperspectral remote sensing assistant."
                fout.write(json.dumps(obj, ensure_ascii=False) + "\n")
                count_out += 1
            else:
                print(f"⚠️ Skipped {fname} (not list or dict)")

print(f"✅ Read {count_in} files → wrote {count_out} lines to {OUT_PATH}")
