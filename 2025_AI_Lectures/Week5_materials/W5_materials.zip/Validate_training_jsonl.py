# quick_check_dataset.py
import json

PATH = r"D:\Hoa_teaching_graduate_classes\2025_fall\W5_materials\all.jsonl"

with open(PATH, "r", encoding="utf-8") as f:
    for i, line in enumerate(f, start=1):
        try:
            obj = json.loads(line)

            # Required fields
            for key in ["system", "instruction", "context", "answer"]:
                if key not in obj or not obj[key].strip():
                    raise ValueError(f"Missing or empty field '{key}'")

        except Exception as e:
            print("Error in line", i, ":", e)
