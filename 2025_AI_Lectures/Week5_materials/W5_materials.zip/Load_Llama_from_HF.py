# D:\Hoa_teaching_graduate_classes\2025_fall\Week5\train_lora.py
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

BASE_MODEL = "meta-llama/Meta-Llama-3.1-8B"   # HF model id

tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL, use_fast=True)
tokenizer.pad_token = tokenizer.eos_token  # safe for causal LMs

model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL,
    device_map="auto",
    load_in_4bit=True,                    # QLoRA path (requires bitsandbytes)
    bnb_4bit_use_double_quant=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16
)
