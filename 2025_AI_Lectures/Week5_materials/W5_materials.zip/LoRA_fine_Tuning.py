import os
import sys
import json
import torch
from typing import Dict
from huggingface_hub import login
from datasets import load_dataset
from transformers import (
    AutoTokenizer, AutoModelForCausalLM,
    TrainingArguments, Trainer, DataCollatorForLanguageModeling
)
from peft import LoraConfig, get_peft_model, TaskType

# ========= USER CONFIG =========
HF_TOKEN = os.environ.get("HF_TOKEN", "hf_XXXXXXXXXXXXX")  # set env or paste token here
BASE_MODEL = "meta-llama/Meta-Llama-3.1-8B"  # exact gated repo id (ensure access approved)

DATA_PATH = r"D:\Hoa_teaching_graduate_classes\2025_fall\W5_materials\all.jsonl"
OUT_RUNS  = r"D:\Hoa_teaching_graduate_classes\2025_fall\W5_materials"
OUT_LOGS  = os.path.join(OUT_RUNS, "logs")
OUT_ADAPT = r"D:\Hoa_teaching_graduate_classes\2025_fall\W5_materials\week5_lora_v01"

MAX_LEN   = 2048          # reduce to 1536/1024 if OOM
BATCH     = 1             # keep =1 for QLoRA; scale via grad accumulation
GRAD_ACC  = 16            # effective batch = BATCH * GRAD_ACC
LR        = 2e-4          # 1e-4 if unstable/verbose; 2e-4..3e-4 if underfitting
EPOCHS    = 1             # start with 1; consider 2–3 if still improving
LORA_R    = 16            # 8–32 typical; lower if OOM, higher if capacity needed
LORA_ALPHA= 32            # 16–64 typical
LORA_DROPOUT = 0.05       # 0.0–0.1 typical
INCLUDE_MLP = True        # True: attn + MLP; False: attention only (saves VRAM)
# ===============================

def ensure_token():
    if not HF_TOKEN.startswith("hf_"):
        print("[!] HF_TOKEN is not set. Set env var HF_TOKEN or edit this file.", file=sys.stderr)
        sys.exit(1)
    login(HF_TOKEN) 

def load_base_model_and_tokenizer():
    print("[+] Loading tokenizer & base model:", BASE_MODEL)
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL, use_fast=True, token=HF_TOKEN)
    # Safe default for causal LMs
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # QLoRA (4-bit); fall back to fp16 if bitsandbytes unavailable
    try:
        model = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL,
            token=HF_TOKEN,
            device_map="auto",
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16
        )
        print("[+] Loaded base model with QLoRA (4-bit).")
    except Exception as e:
        print("[!] 4-bit load failed; falling back to fp16. Error:", e)
        model = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL,
            token=HF_TOKEN,
            device_map="auto",
            torch_dtype=torch.float16
        )
        print("[+] Loaded base model in fp16 fallback.")

    # Slight speed/compatibility improvement for training
    if hasattr(model, "config"):
        model.config.use_cache = False

    return model, tokenizer

def attach_lora(model):
    print("[+] Attaching LoRA adapters ...")
    target_modules = ["q_proj","k_proj","v_proj","o_proj"]
    if INCLUDE_MLP:
        target_modules += ["gate_proj","up_proj","down_proj"]

    lora_cfg = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=LORA_R,
        lora_alpha=LORA_ALPHA,
        lora_dropout=LORA_DROPOUT,
        target_modules=target_modules
    )
    peft_model = get_peft_model(model, lora_cfg)
    trainable = sum(p.numel() for p in peft_model.parameters() if p.requires_grad)
    total     = sum(p.numel() for p in peft_model.parameters())
    print(f"[+] LoRA attached. Trainable params: {trainable:,} / {total:,}")
    return peft_model

def format_row(r: Dict) -> Dict:
    # Require system + instruction + context + answer
    for key in ["system", "instruction", "context", "answer"]:
        if key not in r or not str(r[key]).strip():
            meta = r.get("meta", {})
            raise ValueError(f"Missing/empty '{key}' in record (meta={meta})")

    system = r["system"].strip()
    ins    = r["instruction"].strip()
    ctx    = r["context"].strip()
    ans    = r["answer"].strip()

    prompt = f"{system}\n\nInstruction: {ins}\nContext: {ctx}\nAnswer:"
    return {"prompt": prompt, "label": ans}

def load_and_prepare_dataset(tokenizer):
    if not os.path.isfile(DATA_PATH):
        raise FileNotFoundError(f"DATA_PATH not found: {DATA_PATH}")
    print("[+] Loading dataset:", DATA_PATH)
    raw = load_dataset("json", data_files=DATA_PATH)["train"]

    ds = raw.map(format_row)

    def tokenize(batch):
        enc_p = tokenizer(batch["prompt"], truncation=True, max_length=MAX_LEN)
        enc_a = tokenizer(batch["label"],  truncation=True, max_length=MAX_LEN)

        input_ids  = enc_p["input_ids"] + enc_a["input_ids"]
        attention  = [1] * len(input_ids)
        # Mask prompt tokens -> loss only on answer
        labels     = [-100] * len(enc_p["input_ids"]) + enc_a["input_ids"]
        return {"input_ids": input_ids, "attention_mask": attention, "labels": labels}

    tok_ds = ds.map(tokenize, remove_columns=ds.column_names)
    print(f"[+] Tokenized dataset size: {len(tok_ds)} samples")
    return tok_ds

import math
import csv

def train(model, tokenizer, tok_ds):
    os.makedirs(OUT_RUNS, exist_ok=True)
    os.makedirs(OUT_LOGS, exist_ok=True)
    print("[+] Starting training ...")

    args = TrainingArguments(
        output_dir=OUT_RUNS,
        logging_dir=OUT_LOGS,
        report_to="tensorboard",
        logging_steps=20,
        num_train_epochs=EPOCHS,
        per_device_train_batch_size=BATCH,
        gradient_accumulation_steps=GRAD_ACC,
        learning_rate=LR,
        warmup_ratio=0.03,
        lr_scheduler_type="cosine",
        save_steps=500,
        save_total_limit=2,
        bf16=True
    )

    collator = DataCollatorForLanguageModeling(tokenizer, mlm=False)
    trainer = Trainer(model=model, args=args, data_collator=collator, train_dataset=tok_ds)

    # ---- RUN TRAINING ----
    train_result = trainer.train()

    # ---- FINAL METRICS (loss, runtime, etc.) ----
    metrics = train_result.metrics  # includes "train_loss"
    trainer.log_metrics("train", metrics)   # prints nicely
    trainer.save_metrics("train", metrics)  # writes to runs/train_results.json
    trainer.save_state()

    # Optional: compute perplexity if loss is reasonable
    train_loss = metrics.get("train_loss")
    if train_loss is not None and train_loss < 20:
        ppl = math.exp(train_loss)
        print(f"[+] Final train loss: {train_loss:.4f} | Perplexity: {ppl:.2f}")

    # ---- STEPWISE LOG CSV (loss per logging step) ----
    csv_path = os.path.join(OUT_RUNS, "loss_log.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["step", "epoch", "loss", "learning_rate"])
        for rec in trainer.state.log_history:
            if "loss" in rec:
                w.writerow([rec.get("step"), rec.get("epoch"), rec.get("loss"), rec.get("learning_rate")])
    print("[+] Wrote stepwise loss CSV to:", csv_path)

    print("[+] Training finished.")
    return trainer

def save_adapter(trainer, tokenizer):
    os.makedirs(OUT_ADAPT, exist_ok=True)
    trainer.model.save_pretrained(OUT_ADAPT)
    tokenizer.save_pretrained(OUT_ADAPT)
    print("[+] Saved LoRA adapter + tokenizer to:", OUT_ADAPT)

def smoke_test(model, tokenizer):
    print("[+] Running smoke test generation ...")
    prompt = (
        "You are a geology and hyperspectral remote sensing assistant.\n\n"
        "Instruction: Summarize how dolomitization affected economic value in the study.\n"
        "Context: Results show igneous intrusion reduced economic value by ~80% compared to pure limestone, "
        "and hydrothermal alteration caused extensive dolomitization, transforming limestone into dolostone.\n"
        "Answer:"
    )
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        output_ids = model.generate(
            **inputs, max_new_tokens=200, do_sample=False,
            eos_token_id=tokenizer.eos_token_id
        )
    text = tokenizer.decode(output_ids[0], skip_special_tokens=True)
    print("\n[SMOKE TEST OUTPUT]\n", text, "\n")

def main():
    # Optional: print versions to help debugging
    try:
        import transformers, datasets, peft, accelerate
        print("Versions -> transformers:", transformers.__version__,
              "| datasets:", datasets.__version__,
              "| peft:", peft.__version__,
              "| accelerate:", accelerate.__version__)
    except Exception:
        pass

    ensure_token()
    model, tokenizer = load_base_model_and_tokenizer()
    model = attach_lora(model)
    tok_ds = load_and_prepare_dataset(tokenizer)
    trainer = train(model, tokenizer, tok_ds)
    save_adapter(trainer, tokenizer)
    smoke_test(trainer.model, tokenizer)

if __name__ == "__main__":
    main()
